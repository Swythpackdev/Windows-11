# Security Policy


## Reporting a Vulnerability

Send a message to any of the **SUPER MODS** on the Discord server.

Discord: https://discord.gg/qmEZwUhb4b
