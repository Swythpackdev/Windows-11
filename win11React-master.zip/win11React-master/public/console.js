console.log('%cWin11React is a project by blueedgetechno and ascended by andrewstech. If you wish to help out with this project, visit https://github.com/blueedgetechno/win11React', 'color: lightblue; font-size: x-large');

function removeWarning() {
  document.body.dataset.force = true;
}
